import './App.css';
import Dashboard from './components/Dashboard';
import Login from './components/auth/Logins';
import {BrowserRouter,Routes,Route} from'react-router-dom';
import SignOut from './components/auth/SignOut';

const App=()=>{
  
  return (
   <>
    <BrowserRouter>
    <Routes>
      <Route path="/dashboard" element={<Dashboard />}></Route>
      <Route path="/Login" element={<Login />}></Route>
      <Route path="/" element={<SignOut />}></Route>
    </Routes>
    </BrowserRouter>
   </>
  );
  }


  export default App