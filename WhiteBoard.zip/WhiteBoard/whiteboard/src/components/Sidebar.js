import React ,{useState} from 'react';
import '../css/sidebar.css';
import {SketchPicker} from "react-color"; 
import DrawingArea from './DrawingArea';
// import ReactQuill from 'react-quill';
// import 'react-quill/dist/quill.bubble.css';
// const  modules  = {
//   toolbar: [
//       [{ font: [] }],
//       [{ header: [1, 2, 3, 4, 5, 6, false] }],
//       ["bold", "italic", "underline", "strike"],
//       [{ color: [] }, { background: [] }],
//       [{ script:  "sub" }, { script:  "super" }],
//       ["blockquote", "code-block"],
//       [{ list:  "ordered" }, { list:  "bullet" }],
//       [{ indent:  "-1" }, { indent:  "+1" }, { align: [] }],
//       ["link", "image", "video"],
//       ["clean"],
//   ],
// }

const Sidebar = (props) => {
  const [color, setColor] = useState(" light grey");
  const [hidden, setHidden] = useState(false);
  const [hide, setHide] = useState(false);
  const pickerStyle = {
    default: {
      picker: {
        position: "absolute",
        bottom: "40px",
        left: "100px"
      }
    },
  
    
  };

  return (  
    <div className='diagram'>
     <div className='Filter'> 
      {hidden && (
          <SketchPicker
            styles={pickerStyle}
            color= {color}
            onChange={(updatedColor) => setColor(updatedColor.hex)}
          />
        )}

        <button onClick={() => setHidden(!hidden)}  style={{background:color}}>
          {hidden ? "Close Color Picker" : "Open Color Picker"}
        </button>
       
      <button onClick={()=>setHide(!hide)}>Text</button>
      <input type="radio" />
      <label>Pencil</label>
      <select id="cars">
      <option value="volvo">Rectangle</option>
      <option value="saab">square</option>
      <option value="opel">Triangle</option>
      
      </select>
     
      <button >Undo</button><button>Redo</button>
      </div>
      <div className='nextpage'>
         <DrawingArea  images={props.imagesource} hides={hide}/>
      </div>
    </div>
    
  )
}

export default Sidebar
