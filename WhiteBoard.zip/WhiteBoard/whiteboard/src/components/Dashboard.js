import React, { useRef, useState } from 'react';             
import '../css/dashboard.css';                   
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import Sidebar from './Sidebar';
import avatar from './images/avatar.png';
import { useNavigate } from 'react-router-dom';

const Dashboard = (props) => {
  const navigate=useNavigate();
  const inputRef=useRef();
  
  const[image,setImage]=useState("");

  const newPage=()=>{
    window.location.reload(false);
  }

 const handleOut=()=>{ 
     //alert("shdcbsdmbcmsd");
     inputRef.current.click(); 
  }
  const handleClick=(event )=>{
     const file=event.target.files[0];
      
            setImage(file);
          }
   const handleAvatar=()=>{
    if(window.confirm('Are You sure to Logout')){
      
      navigate('/')
      console.log("Logged Out")
       
    }
    else  {
        console.log("error");
      }
                          
}
  return ( 
    <div>
     <Stack direction="row" spacing={3}>
      
      <Avatar sx={{ width: 44, height: 44 }}
      alt="Remy Sharp" 
      onClick={handleAvatar}
      src={avatar}  
      variant="round"/>
     <button   onClick={newPage}>New Page </button> 
     <button  onClick={handleOut}>
      Upload Photo   
      <input type="file" ref={inputRef} onChange={handleClick} accept="image/png, image/jpeg" style={{display:"none"}}/>
      </button>
      
      <button >Save</button>
    
      </Stack>
            
      <Sidebar imagesource={image} />
      
    </div>
  )
}

export default Dashboard
