import React from 'react'
import {  useNavigate } from 'react-router-dom';
const SignOut = () => {
  const navigate=useNavigate();
  const handleSignUp=()=>{
       navigate('/dashboard');
  }
  
  return (
    <div>
      <label>Name</label>
      <input type="text" placeholder="Arav" size="10" required/>
       <label>UserName</label>
      <input type="Email" placeholder="cmn bcmbm" size="50" required/>
      <label>Password</label>
      <input type="text" placeholder="1245678" size="10" required/>
      <button onClick={handleSignUp}>SignUp</button>
      <button onClick={()=>{navigate('/Login')}}>Login</button>
    </div>
  )
}

export default SignOut
