import React from 'react'
import {  useNavigate } from 'react-router-dom';

const Logins = () => {
  const navigate=useNavigate();

  const handleLogin=()=>{
    navigate("/dashboard");
  }

  return (
    <div>
      <label>UserName</label>
      <input type="Email" placeholder="cmn bcmbm" size="50" required/>
      <label>Password</label>
      <input type="Password" placeholder="1245678" size="10" required/>
      <a>Forget password</a>
      <button onClick={handleLogin}>Login</button>
    </div>
  )
}

export default Logins
