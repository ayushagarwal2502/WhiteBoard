const mongoose=require('mongoose');


const db =()=>{
mongoose.connect("mongodb+srv://ayushagarwal2502:Ayush1234@cluster0.8nc3l0t.mongodb.net/?retryWrites=true&w=majority",{
    useNewUrlParser:true ,
    useUnifiedTopology:true
  }).then(()=>{ 
    console.log("mongo db connected succesfully"); 
  }).catch((error)=>{
    console.log(error); 
  }) 
}
module.exports.connect=(db);  